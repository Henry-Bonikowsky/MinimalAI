package com.minimalai.ui;

import com.minimalai.ai.AIController;
import com.minimalai.ai.Trainer;
import com.minimalai.playback.PlaybackController;
import com.minimalai.recording.RecordingManager;
import com.minimalai.recording.RecordingStorage;
import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Main dashboard screen for MinimalAI.
 * Shows recording/training/playback controls and lists.
 */
public class DashboardScreen extends class_437 {
    private static final int BUTTON_WIDTH = 100;
    private static final int BUTTON_HEIGHT = 20;
    private static final int PADDING = 10;

    // Colors
    private static final int RED = 0xFFFF4444;
    private static final int GREEN = 0xFF44FF44;
    private static final int YELLOW = 0xFFFFFF44;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;
    private static final int DARK_GRAY = 0xFF333333;

    private List<RecordingStorage.RecordingInfo> recordings;
    private List<Path> models;
    private int selectedRecordingIndex = -1;
    private int selectedModelIndex = -1;

    private class_4185 recordButton;
    private class_4185 playButton;
    private class_4185 trainButton;
    private class_4185 aiButton;
    private class_4185 deleteButton;
    private class_4185 deleteModelsButton;

    public DashboardScreen() {
        super(class_2561.method_43470("MinimalAI Dashboard"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        // Refresh recordings and models lists
        recordings = RecordingManager.getInstance().getStorage().listRecordings();
        models = AIController.getInstance().listModels();

        int centerX = field_22789 / 2;
        int buttonY = 40;

        // Main action buttons at top
        recordButton = class_4185.method_46430(class_2561.method_43470("Record"), button -> onRecord())
            .method_46434(centerX - 210, buttonY, BUTTON_WIDTH, BUTTON_HEIGHT)
            .method_46431();
        method_37063(recordButton);

        playButton = class_4185.method_46430(class_2561.method_43470("Play"), button -> onPlay())
            .method_46434(centerX - 105, buttonY, BUTTON_WIDTH, BUTTON_HEIGHT)
            .method_46431();
        method_37063(playButton);

        trainButton = class_4185.method_46430(class_2561.method_43470("Train"), button -> onTrain())
            .method_46434(centerX, buttonY, BUTTON_WIDTH, BUTTON_HEIGHT)
            .method_46431();
        method_37063(trainButton);

        aiButton = class_4185.method_46430(class_2561.method_43470("Run AI"), button -> onAI())
            .method_46434(centerX + 105, buttonY, BUTTON_WIDTH, BUTTON_HEIGHT)
            .method_46431();
        method_37063(aiButton);

        // Delete button for selected recording
        deleteButton = class_4185.method_46430(class_2561.method_43470("Delete Rec"), button -> onDelete())
            .method_46434(PADDING, field_22790 - BUTTON_HEIGHT - PADDING, BUTTON_WIDTH, BUTTON_HEIGHT)
            .method_46431();
        deleteButton.field_22763 = false;
        method_37063(deleteButton);

        // Delete models button
        deleteModelsButton = class_4185.method_46430(class_2561.method_43470("Delete Models"), button -> onDeleteModels())
            .method_46434(field_22789 - BUTTON_WIDTH - PADDING, field_22790 - BUTTON_HEIGHT - PADDING, BUTTON_WIDTH, BUTTON_HEIGHT)
            .method_46431();
        method_37063(deleteModelsButton);

        // Close button
        method_37063(class_4185.method_46430(class_2561.method_43470("Close"), button -> method_25419())
            .method_46434(centerX - 50, field_22790 - BUTTON_HEIGHT - PADDING, BUTTON_WIDTH, BUTTON_HEIGHT)
            .method_46431());

        updateButtonStates();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Let super handle background (don't call renderBackground ourselves - causes blur crash in 1.21+)
        super.method_25394(context, mouseX, mouseY, delta);

        // Title
        context.method_27534(field_22793, field_22785, field_22789 / 2, 15, WHITE);

        // Status line
        String status = getStatusText();
        int statusColor = getStatusColor();
        context.method_25300(field_22793, status, field_22789 / 2, 65, statusColor);

        // Recordings list
        int listX = PADDING;
        int listY = 85;
        int listWidth = field_22789 / 2 - PADDING * 2;
        int listHeight = field_22790 - listY - 50;

        // List header
        context.method_25303(field_22793, "Recordings (" + recordings.size() + ")", listX, listY, WHITE);
        listY += 15;

        // List background
        context.method_25294(listX, listY, listX + listWidth, listY + listHeight, 0x88000000);

        // List items
        int itemY = listY + 2;
        int itemHeight = 24;
        for (int i = 0; i < recordings.size() && itemY + itemHeight < listY + listHeight; i++) {
            RecordingStorage.RecordingInfo info = recordings.get(i);

            boolean isHovered = mouseX >= listX && mouseX < listX + listWidth &&
                               mouseY >= itemY && mouseY < itemY + itemHeight;
            boolean isSelected = i == selectedRecordingIndex;

            // Item background
            if (isSelected) {
                context.method_25294(listX + 1, itemY, listX + listWidth - 1, itemY + itemHeight, 0xFF446688);
            } else if (isHovered) {
                context.method_25294(listX + 1, itemY, listX + listWidth - 1, itemY + itemHeight, 0xFF333344);
            }

            // Recording name
            context.method_25303(field_22793, info.name, listX + 5, itemY + 2, WHITE);

            // Recording details
            String details = String.format("%s | %d frames | %.0f FPS",
                info.getFormattedDuration(), info.frameCount, info.avgFps);
            context.method_25303(field_22793, details, listX + 5, itemY + 12, GRAY);

            itemY += itemHeight;
        }

        // Training stats (right side)
        int statsX = field_22789 / 2 + PADDING;
        int statsY = 85;

        context.method_25303(field_22793, "Training Stats", statsX, statsY, WHITE);
        statsY += 15;

        Trainer trainer = Trainer.getInstance();
        if (trainer.isTraining()) {
            context.method_25303(field_22793,
                String.format("Epoch: %d/%d", trainer.getCurrentEpoch() + 1, trainer.getTotalEpochs()),
                statsX, statsY, YELLOW);
            statsY += 12;
        }

        context.method_25303(field_22793,
            String.format("Action Loss: %.4f", trainer.getLastActionLoss()),
            statsX, statsY, GRAY);
        statsY += 12;

        context.method_25303(field_22793,
            String.format("Camera Loss: %.4f", trainer.getLastCameraLoss()),
            statsX, statsY, GRAY);
        statsY += 12;

        context.method_25303(field_22793,
            String.format("Accuracy: %.1f%%", trainer.getLastActionAccuracy()),
            statsX, statsY, GRAY);
        statsY += 20;

        // Models list
        int modelListY = statsY;
        int modelListWidth = field_22789 / 2 - PADDING * 2;
        int modelListHeight = field_22790 - modelListY - 50;
        int modelItemHeight = 16;

        context.method_25303(field_22793, "Models (" + models.size() + ")", statsX, modelListY, WHITE);
        modelListY += 15;

        // List background
        context.method_25294(statsX, modelListY, statsX + modelListWidth, modelListY + modelListHeight, 0x88000000);

        // List items
        int modelItemY = modelListY + 2;
        for (int i = 0; i < models.size() && modelItemY + modelItemHeight < modelListY + modelListHeight; i++) {
            Path model = models.get(i);
            String modelName = model.getFileName().toString();

            boolean isHovered = mouseX >= statsX && mouseX < statsX + modelListWidth &&
                               mouseY >= modelItemY && mouseY < modelItemY + modelItemHeight;
            boolean isSelected = i == selectedModelIndex;

            // Item background
            if (isSelected) {
                context.method_25294(statsX + 1, modelItemY, statsX + modelListWidth - 1, modelItemY + modelItemHeight, 0xFF446688);
            } else if (isHovered) {
                context.method_25294(statsX + 1, modelItemY, statsX + modelListWidth - 1, modelItemY + modelItemHeight, 0xFF333344);
            }

            // Model name (truncate if needed)
            String displayName = modelName.length() > 25 ? modelName.substring(0, 22) + "..." : modelName;
            context.method_25303(field_22793, displayName, statsX + 5, modelItemY + 4, WHITE);

            modelItemY += modelItemHeight;
        }

        // Keybind hints
        int hintY = field_22790 - 35;
        context.method_25300(field_22793,
            "R=Record  P=Play  T=Train  I=AI  End=Stop", field_22789 / 2, hintY, GRAY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // Check if clicked on recording list (left side)
        int listX = PADDING;
        int listY = 100;
        int listWidth = field_22789 / 2 - PADDING * 2;
        int itemHeight = 24;

        if (mouseX >= listX && mouseX < listX + listWidth && mouseY >= listY) {
            int clickedIndex = (int) ((mouseY - listY) / itemHeight);
            if (clickedIndex >= 0 && clickedIndex < recordings.size()) {
                selectedRecordingIndex = clickedIndex;
                updateButtonStates();
                return true;
            }
        }

        // Check if clicked on model list (right side)
        int statsX = field_22789 / 2 + PADDING;
        int modelListY = 85 + 15 + 12 + 12 + 12 + 20 + 15; // After training stats
        int modelListWidth = field_22789 / 2 - PADDING * 2;
        int modelItemHeight = 16;

        if (mouseX >= statsX && mouseX < statsX + modelListWidth && mouseY >= modelListY) {
            int clickedIndex = (int) ((mouseY - modelListY - 2) / modelItemHeight);
            if (clickedIndex >= 0 && clickedIndex < models.size()) {
                selectedModelIndex = clickedIndex;
                updateButtonStates();
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    private void updateButtonStates() {
        boolean isRecording = RecordingManager.getInstance().isRecording();
        boolean isPlaying = PlaybackController.getInstance().isPlaying();
        boolean isTraining = Trainer.getInstance().isTraining();
        boolean isAI = AIController.getInstance().isRunning();

        recordButton.method_25355(class_2561.method_43470(isRecording ? "Stop Rec" : "Record"));
        playButton.method_25355(class_2561.method_43470(isPlaying ? "Stop Play" : "Play"));
        trainButton.method_25355(class_2561.method_43470(isTraining ? "Stop Train" : "Train"));
        aiButton.method_25355(class_2561.method_43470(isAI ? "Stop AI" : "Run AI"));

        playButton.field_22763 = !recordings.isEmpty() || isPlaying;
        trainButton.field_22763 = !recordings.isEmpty() || isTraining;
        aiButton.field_22763 = !models.isEmpty() || isAI;
        deleteButton.field_22763 = selectedRecordingIndex >= 0 && !isRecording && !isPlaying;
        deleteModelsButton.field_22763 = !models.isEmpty() && !isAI;
    }

    private String getStatusText() {
        if (RecordingManager.getInstance().isRecording()) {
            return "● Recording...";
        }
        if (PlaybackController.getInstance().isPlaying()) {
            return "▶ Playing...";
        }
        if (Trainer.getInstance().isTraining()) {
            return "⚡ Training...";
        }
        if (AIController.getInstance().isRunning()) {
            return "🤖 AI Running...";
        }
        return "Ready";
    }

    private int getStatusColor() {
        if (RecordingManager.getInstance().isRecording()) return RED;
        if (PlaybackController.getInstance().isPlaying()) return GREEN;
        if (Trainer.getInstance().isTraining()) return YELLOW;
        if (AIController.getInstance().isRunning()) return 0xFF44FFFF; // CYAN
        return WHITE;
    }

    private void onRecord() {
        RecordingManager.getInstance().toggleRecording();
        if (!RecordingManager.getInstance().isRecording()) {
            // Refresh list after stopping
            recordings = RecordingManager.getInstance().getStorage().listRecordings();
        }
        updateButtonStates();
    }

    private void onPlay() {
        if (PlaybackController.getInstance().isPlaying()) {
            PlaybackController.getInstance().stop();
        } else if (selectedRecordingIndex >= 0 && selectedRecordingIndex < recordings.size()) {
            method_25419();
            PlaybackController.getInstance().play(recordings.get(selectedRecordingIndex).name);
        } else if (!recordings.isEmpty()) {
            method_25419();
            PlaybackController.getInstance().playLatest();
        }
        updateButtonStates();
    }

    private void onTrain() {
        if (Trainer.getInstance().isTraining()) {
            Trainer.getInstance().stopTraining();
        } else {
            Trainer.getInstance().startTraining();
        }
        updateButtonStates();
    }

    private void onAI() {
        if (AIController.getInstance().isRunning()) {
            AIController.getInstance().stop();
        } else if (selectedModelIndex >= 0 && selectedModelIndex < models.size()) {
            // Use selected model
            method_25419();
            AIController.getInstance().start(models.get(selectedModelIndex));
        } else if (!models.isEmpty()) {
            // Use latest model
            method_25419();
            AIController.getInstance().start();
        }
        updateButtonStates();
    }

    private void onDelete() {
        if (selectedRecordingIndex >= 0 && selectedRecordingIndex < recordings.size()) {
            String name = recordings.get(selectedRecordingIndex).name;
            RecordingManager.getInstance().getStorage().delete(name);
            recordings = RecordingManager.getInstance().getStorage().listRecordings();
            selectedRecordingIndex = -1;
            updateButtonStates();
        }
    }

    private void onDeleteModels() {
        AIController.getInstance().deleteAllModels();
        models = AIController.getInstance().listModels();
        updateButtonStates();
    }

    @Override
    public void method_25393() {
        super.method_25393();
        models = AIController.getInstance().listModels();
        updateButtonStates();
    }

    @Override
    public boolean method_25421() {
        return false; // Don't pause game while dashboard is open
    }
}
