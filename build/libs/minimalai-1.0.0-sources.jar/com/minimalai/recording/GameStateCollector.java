package com.minimalai.recording;

import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_746;
import net.minecraft.class_7923;

/**
 * Collects game state as 64 normalized float values for neural network input.
 *
 * Layout:
 * [0-7]   Player state: health, hunger, air, pos_y, vel_x, vel_y, vel_z, on_ground
 * [8-9]   Reserved (zeros) - rotation removed to prevent feedback loops
 * [10-15] Crosshair: block_type, entity_type, distance, hardness, break_progress, is_attacking
 * [16-55] Raycasts: 10 directions × 4 values (type, distance, solid, entity)
 * [56-59] Inventory: selected_slot, has_tool, has_weapon, inventory_full
 * [60-63] Movement: sprinting, sneaking, swimming, flying
 */
public class GameStateCollector {
    public static final int STATE_SIZE = 64;

    // Raycast directions (relative to player facing)
    private static final float[][] RAYCAST_ANGLES = {
        {0, 0},      // front
        {45, 0},     // front-right
        {90, 0},     // right
        {135, 0},    // back-right
        {180, 0},    // back
        {-135, 0},   // back-left
        {-90, 0},    // left
        {-45, 0},    // front-left
        {0, -90},    // up
        {0, 90}      // down
    };

    private static final float RAYCAST_DISTANCE = 20.0f;

    private final class_310 client;
    private float blockBreakProgress = 0;
    private boolean isAttacking = false;

    public GameStateCollector() {
        this.client = class_310.method_1551();
    }

    public void setBlockBreakProgress(float progress) {
        this.blockBreakProgress = progress;
    }

    public void setIsAttacking(boolean attacking) {
        this.isAttacking = attacking;
    }

    public float[] collect() {
        float[] state = new float[STATE_SIZE];

        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null) {
            return state; // Return zeros if no player
        }

        int idx = 0;

        // Player state (8 values)
        state[idx++] = player.method_6032() / 20.0f;  // Normalize to 0-1
        state[idx++] = player.method_7344().method_7586() / 20.0f;
        state[idx++] = player.method_5669() / (float) player.method_5748();
        state[idx++] = normalizeHeight(player.method_23318());
        state[idx++] = (float) clamp(player.method_18798().field_1352, -1, 1);
        state[idx++] = (float) clamp(player.method_18798().field_1351, -1, 1);
        state[idx++] = (float) clamp(player.method_18798().field_1350, -1, 1);
        state[idx++] = player.method_24828() ? 1.0f : 0.0f;

        // Reserved (2 values) - previously rotation, removed to prevent feedback loop
        // Camera movement should be based on what the network sees (raycasts), not current orientation
        state[idx++] = 0.0f;
        state[idx++] = 0.0f;

        // Crosshair info (6 values)
        idx = collectCrosshair(state, idx, player);

        // Raycasts (40 values)
        idx = collectRaycasts(state, idx, player);

        // Inventory (4 values)
        idx = collectInventory(state, idx, player);

        // Movement state (4 values)
        state[idx++] = player.method_5624() ? 1.0f : 0.0f;
        state[idx++] = player.method_5715() ? 1.0f : 0.0f;
        state[idx++] = player.method_5681() ? 1.0f : 0.0f;
        state[idx++] = player.method_31549().field_7479 ? 1.0f : 0.0f;

        return state;
    }

    private int collectCrosshair(float[] state, int idx, class_746 player) {
        class_239 hit = client.field_1765;

        if (hit == null || hit.method_17783() == class_239.class_240.field_1333) {
            // Looking at nothing
            state[idx++] = 0; // block type (air)
            state[idx++] = 0; // entity type (none)
            state[idx++] = 1; // distance (max)
            state[idx++] = 0; // hardness
            state[idx++] = blockBreakProgress;
            state[idx++] = isAttacking ? 1.0f : 0.0f;
        } else if (hit.method_17783() == class_239.class_240.field_1332) {
            class_3965 blockHit = (class_3965) hit;
            class_2680 blockState = client.field_1687.method_8320(blockHit.method_17777());

            state[idx++] = categorizeBlock(blockState);
            state[idx++] = 0; // entity type (none)
            state[idx++] = (float) Math.min(hit.method_17784().method_1022(player.method_33571()) / RAYCAST_DISTANCE, 1.0);
            state[idx++] = normalizeHardness(blockState.method_26214(client.field_1687, blockHit.method_17777()));
            state[idx++] = blockBreakProgress;
            state[idx++] = isAttacking ? 1.0f : 0.0f;
        } else if (hit.method_17783() == class_239.class_240.field_1331) {
            class_3966 entityHit = (class_3966) hit;
            class_1297 entity = entityHit.method_17782();

            state[idx++] = 0; // block type (air - looking at entity)
            state[idx++] = categorizeEntity(entity);
            state[idx++] = (float) Math.min(hit.method_17784().method_1022(player.method_33571()) / RAYCAST_DISTANCE, 1.0);
            state[idx++] = 0; // hardness (N/A for entities)
            state[idx++] = 0; // break progress (N/A)
            state[idx++] = isAttacking ? 1.0f : 0.0f;
        } else {
            // Fallback
            state[idx++] = 0;
            state[idx++] = 0;
            state[idx++] = 1;
            state[idx++] = 0;
            state[idx++] = 0;
            state[idx++] = 0;
        }

        return idx;
    }

    private int collectRaycasts(float[] state, int idx, class_746 player) {
        class_1937 world = client.field_1687;
        class_243 eyePos = player.method_33571();
        float playerYaw = player.method_36454();
        float playerPitch = player.method_36455();

        for (float[] angles : RAYCAST_ANGLES) {
            float yawOffset = angles[0];
            float pitchOffset = angles[1];

            // Calculate direction
            float yaw = playerYaw + yawOffset;
            float pitch = playerPitch + pitchOffset;

            // Clamp pitch
            pitch = Math.max(-90, Math.min(90, pitch));

            // Convert to direction vector
            double yawRad = Math.toRadians(yaw);
            double pitchRad = Math.toRadians(pitch);

            double x = -Math.sin(yawRad) * Math.cos(pitchRad);
            double y = -Math.sin(pitchRad);
            double z = Math.cos(yawRad) * Math.cos(pitchRad);

            class_243 direction = new class_243(x, y, z).method_1029();
            class_243 endPos = eyePos.method_1019(direction.method_1021(RAYCAST_DISTANCE));

            // Block raycast
            class_3965 blockHit = world.method_17742(new class_3959(
                eyePos, endPos, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, player
            ));

            float blockType = 0;
            float distance = 1;
            float isSolid = 0;
            float hasEntity = 0;

            if (blockHit.method_17783() == class_239.class_240.field_1332) {
                class_2680 blockState = world.method_8320(blockHit.method_17777());
                blockType = categorizeBlock(blockState);
                distance = (float) Math.min(blockHit.method_17784().method_1022(eyePos) / RAYCAST_DISTANCE, 1.0);
                isSolid = blockState.method_26212(world, blockHit.method_17777()) ? 1.0f : 0.0f;
            }

            // Entity check in this direction
            for (class_1297 entity : world.method_8390(class_1309.class,
                    player.method_5829().method_1014(RAYCAST_DISTANCE), e -> e != player)) {
                class_243 toEntity = entity.method_19538().method_1031(0, entity.method_17682() / 2, 0).method_1020(eyePos);
                double dot = toEntity.method_1029().method_1026(direction);
                if (dot > 0.9) { // Within ~25 degrees
                    double entityDist = toEntity.method_1033();
                    if (entityDist < RAYCAST_DISTANCE && entityDist / RAYCAST_DISTANCE < distance) {
                        hasEntity = categorizeEntity(entity);
                        break;
                    }
                }
            }

            state[idx++] = blockType;
            state[idx++] = distance;
            state[idx++] = isSolid;
            state[idx++] = hasEntity;
        }

        return idx;
    }

    private int collectInventory(float[] state, int idx, class_746 player) {
        state[idx++] = player.method_31548().method_67532() / 8.0f; // Normalize 0-8 to 0-1

        // Check for tools and weapons using item ID
        boolean hasTool = false;
        boolean hasWeapon = false;
        int filledSlots = 0;

        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (!stack.method_7960()) {
                filledSlots++;
                String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString().toLowerCase();

                // Tools: pickaxes, axes, shovels, hoes
                if (itemId.contains("pickaxe") || itemId.contains("axe") ||
                    itemId.contains("shovel") || itemId.contains("hoe")) {
                    hasTool = true;
                }
                // Weapons: swords, axes, bows, crossbows, tridents
                if (itemId.contains("sword") || itemId.contains("axe") ||
                    itemId.contains("bow") || itemId.contains("trident")) {
                    hasWeapon = true;
                }
            }
        }

        state[idx++] = hasTool ? 1.0f : 0.0f;
        state[idx++] = hasWeapon ? 1.0f : 0.0f;
        state[idx++] = filledSlots >= 36 ? 1.0f : 0.0f; // Main inventory full

        return idx;
    }

    private float categorizeBlock(class_2680 blockState) {
        class_2248 block = blockState.method_26204();

        if (blockState.method_26215()) return 0.0f;

        String name = block.method_63499().toLowerCase();

        // Ores (valuable)
        if (name.contains("ore")) return 0.9f;

        // Wood/logs
        if (name.contains("log") || name.contains("wood") || name.contains("plank")) return 0.7f;

        // Plants/crops
        if (name.contains("leaves") || name.contains("grass") || name.contains("flower") ||
            name.contains("crop") || name.contains("wheat") || name.contains("carrot")) return 0.3f;

        // Water/lava
        if (block == class_2246.field_10382) return 0.2f;
        if (block == class_2246.field_10164) return 0.1f;

        // Default solid block
        return 0.5f;
    }

    private float categorizeEntity(class_1297 entity) {
        if (entity instanceof class_1657) return 1.0f;
        if (entity instanceof class_1588) return 0.8f;
        if (entity instanceof class_1296) return 0.4f;
        return 0.2f; // Other (items, projectiles, etc.)
    }

    private float normalizeHardness(float hardness) {
        if (hardness < 0) return 1.0f; // Unbreakable
        return (float) Math.min(hardness / 50.0, 1.0); // Obsidian is 50
    }

    private float normalizeHeight(double y) {
        // Minecraft world height is roughly -64 to 320
        return (float) clamp((y + 64) / 384.0, 0, 1);
    }

    private double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
