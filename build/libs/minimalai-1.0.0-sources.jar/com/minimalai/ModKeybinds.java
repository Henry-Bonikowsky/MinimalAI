package com.minimalai;

import com.minimalai.ai.AIController;
import com.minimalai.ai.RLController;
import com.minimalai.ai.Trainer;
import com.minimalai.playback.PlaybackController;
import com.minimalai.recording.RecordingManager;
import com.minimalai.ui.DashboardScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ModKeybinds {
    private static class_304 dashboardKey;
    private static class_304 recordKey;
    private static class_304 playbackKey;
    private static class_304 trainKey;
    private static class_304 aiKey;
    private static class_304 rlKey;
    private static class_304 stopKey;

    public static void register() {
        // Y - Open dashboard
        dashboardKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minimalai.dashboard",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_Y,
            "key.category.minimalai"
        ));

        // R - Toggle recording
        recordKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minimalai.record",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_R,
            "key.category.minimalai"
        ));

        // P - Play latest recording
        playbackKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minimalai.playback",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_P,
            "key.category.minimalai"
        ));

        // T - Train on recordings
        trainKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minimalai.train",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_T,
            "key.category.minimalai"
        ));

        // I - Run AI
        aiKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minimalai.ai",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_I,
            "key.category.minimalai"
        ));

        // L - RL Training (Learn)
        rlKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minimalai.rl",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_L,
            "key.category.minimalai"
        ));

        // End - Stop everything
        stopKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.minimalai.stop",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_END,
            "key.category.minimalai"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(ModKeybinds::onTick);

        MinimalAI.LOGGER.info("Keybinds registered: Y=Dashboard, R=Record, P=Play, T=Train, I=AI, L=RL, End=Stop");
    }

    private static void onTick(class_310 client) {
        if (client.field_1724 == null) return;

        while (dashboardKey.method_1436()) {
            if (client.field_1755 == null) {
                client.method_1507(new DashboardScreen());
            } else if (client.field_1755 instanceof DashboardScreen) {
                client.method_1507(null);
            }
        }

        while (recordKey.method_1436()) {
            MinimalAI.LOGGER.info("Record key pressed (R)");
            // Stop playback if playing
            if (PlaybackController.getInstance().isPlaying()) {
                PlaybackController.getInstance().stop();
            }
            RecordingManager.getInstance().toggleRecording();
        }

        while (playbackKey.method_1436()) {
            MinimalAI.LOGGER.info("Playback key pressed (P)");
            // Stop recording if recording
            if (RecordingManager.getInstance().isRecording()) {
                RecordingManager.getInstance().stopRecording();
            }
            // Toggle playback
            if (PlaybackController.getInstance().isPlaying()) {
                PlaybackController.getInstance().togglePause();
            } else {
                PlaybackController.getInstance().playLatest();
            }
        }

        while (trainKey.method_1436()) {
            MinimalAI.LOGGER.info("Train key pressed (T)");
            if (Trainer.getInstance().isTraining()) {
                Trainer.getInstance().stopTraining();
            } else {
                // Stop recording/playback/AI before training
                if (RecordingManager.getInstance().isRecording()) {
                    RecordingManager.getInstance().stopRecording();
                }
                if (PlaybackController.getInstance().isPlaying()) {
                    PlaybackController.getInstance().stop();
                }
                if (AIController.getInstance().isRunning()) {
                    AIController.getInstance().stop();
                }
                Trainer.getInstance().startTraining();
            }
        }

        while (aiKey.method_1436()) {
            MinimalAI.LOGGER.info("AI key pressed (I)");
            if (AIController.getInstance().isRunning()) {
                AIController.getInstance().stop();
            } else {
                // Stop recording/playback/RL before AI
                if (RecordingManager.getInstance().isRecording()) {
                    RecordingManager.getInstance().stopRecording();
                }
                if (PlaybackController.getInstance().isPlaying()) {
                    PlaybackController.getInstance().stop();
                }
                if (RLController.getInstance().isRunning()) {
                    RLController.getInstance().stop();
                }
                AIController.getInstance().start();
            }
        }

        while (rlKey.method_1436()) {
            MinimalAI.LOGGER.info("RL key pressed (L)");
            if (RLController.getInstance().isRunning()) {
                RLController.getInstance().stop();
            } else {
                // Stop recording/playback/AI before RL
                if (RecordingManager.getInstance().isRecording()) {
                    RecordingManager.getInstance().stopRecording();
                }
                if (PlaybackController.getInstance().isPlaying()) {
                    PlaybackController.getInstance().stop();
                }
                if (AIController.getInstance().isRunning()) {
                    AIController.getInstance().stop();
                }
                if (Trainer.getInstance().isTraining()) {
                    Trainer.getInstance().stopTraining();
                }
                RLController.getInstance().start();
            }
        }

        while (stopKey.method_1436()) {
            MinimalAI.LOGGER.info("Stop key pressed (End)");
            if (RecordingManager.getInstance().isRecording()) {
                RecordingManager.getInstance().stopRecording();
            }
            if (PlaybackController.getInstance().isPlaying()) {
                PlaybackController.getInstance().stop();
            }
            if (Trainer.getInstance().isTraining()) {
                Trainer.getInstance().stopTraining();
            }
            if (AIController.getInstance().isRunning()) {
                AIController.getInstance().stop();
            }
            if (RLController.getInstance().isRunning()) {
                RLController.getInstance().stop();
            }
        }
    }
}
