package com.minimalai.playback;

import com.minimalai.recording.ActionRecorder;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Executes recorded actions on the player.
 * Handles both discrete actions (key presses) and continuous actions (camera).
 */
public class ActionExecutor {
    private final class_310 client;

    public ActionExecutor() {
        this.client = class_310.method_1551();
    }

    /**
     * Apply discrete actions (key states).
     * Actions array layout:
     * [0-3]   Movement: forward, back, left, right
     * [4-6]   Jump, sneak, sprint
     * [7-8]   Attack, use
     * [9-17]  Hotbar slots 1-9
     * [18-19] Drop, swap hands
     */
    public void applyDiscreteActions(boolean[] actions) {
        if (client.field_1724 == null || client.field_1690 == null) return;

        // Movement
        setKeyState(client.field_1690.field_1894, actions[0]);
        setKeyState(client.field_1690.field_1881, actions[1]);
        setKeyState(client.field_1690.field_1913, actions[2]);
        setKeyState(client.field_1690.field_1849, actions[3]);

        // Jump, sneak, sprint
        setKeyState(client.field_1690.field_1903, actions[4]);
        setKeyState(client.field_1690.field_1832, actions[5]);
        setKeyState(client.field_1690.field_1867, actions[6]);

        // Attack, use
        setKeyState(client.field_1690.field_1886, actions[7]);
        setKeyState(client.field_1690.field_1904, actions[8]);

        // Hotbar slots - select if pressed
        for (int i = 0; i < 9; i++) {
            if (actions[9 + i]) {
                client.field_1724.method_31548().method_61496(i);
            }
        }

        // Drop, swap hands
        setKeyState(client.field_1690.field_1869, actions[18]);
        setKeyState(client.field_1690.field_1831, actions[19]);
    }

    /**
     * Apply continuous actions (camera movement).
     * Values are normalized - will be denormalized back to degrees.
     * @param yawDelta Normalized yaw delta
     * @param pitchDelta Normalized pitch delta
     */
    public void applyCameraMovement(float yawDelta, float pitchDelta) {
        class_746 player = client.field_1724;
        if (player == null) return;

        // Denormalize from [-1, 1] back to degrees
        float yawDeg = yawDelta * ActionRecorder.CAMERA_NORMALIZE_SCALE;
        float pitchDeg = pitchDelta * ActionRecorder.CAMERA_NORMALIZE_SCALE;

        float newYaw = player.method_36454() + yawDeg;
        float newPitch = player.method_36455() + pitchDeg;

        // Clamp pitch to valid range
        newPitch = Math.max(-90.0f, Math.min(90.0f, newPitch));

        player.method_36456(newYaw);
        player.method_36457(newPitch);
    }

    /**
     * Release all keys - call when stopping playback.
     */
    public void releaseAllKeys() {
        if (client.field_1690 == null) return;

        setKeyState(client.field_1690.field_1894, false);
        setKeyState(client.field_1690.field_1881, false);
        setKeyState(client.field_1690.field_1913, false);
        setKeyState(client.field_1690.field_1849, false);
        setKeyState(client.field_1690.field_1903, false);
        setKeyState(client.field_1690.field_1832, false);
        setKeyState(client.field_1690.field_1867, false);
        setKeyState(client.field_1690.field_1886, false);
        setKeyState(client.field_1690.field_1904, false);
        setKeyState(client.field_1690.field_1869, false);
        setKeyState(client.field_1690.field_1831, false);
    }

    private void setKeyState(class_304 key, boolean pressed) {
        key.method_23481(pressed);
    }
}
